# Plugin-opcua-client
Plugin opcua client

Use a library node-opcua: https://github.com/node-opcua/node-opcua
